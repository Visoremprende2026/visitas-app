// ============================================================
//  app/(invitado)/entrada.js — Pantalla principal del invitado
//  BLE scan automatico + boton manual de respaldo
// ============================================================

import { useState, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  Alert, ActivityIndicator, FlatList
} from 'react-native';
import { useBLE } from '../../hooks/useBLE';
import { api } from '../../services/api';
import { useAuth } from '../../hooks/useAuth';

// Estados de la pantalla
const ESTADO = {
  BUSCANDO:   'buscando',   // Escaneando BLE
  ABRIENDO:   'abriendo',   // Request al backend en curso
  ABIERTA:    'abierta',    // Exito — puerta abierta
  ERROR:      'error',      // Fallo
};

export default function Entrada() {
  const { usuario, cerrarSesion } = useAuth();
  const [invitaciones, setInvitaciones] = useState([]);
  const [estado, setEstado] = useState(ESTADO.BUSCANDO);
  const [puertaAbierta, setPuertaAbierta] = useState('');
  const [mensajeError, setMensajeError] = useState('');

  // UUIDs de los beacons de las invitaciones activas
  const uuidsBeacon = invitaciones.map(inv => inv.uuid_ble).filter(Boolean);

  // Hook BLE — detecta automaticamente y llama a handleBeaconDetectado
  const { escaneando } = useBLE(uuidsBeacon, handleBeaconDetectado);

  useEffect(() => {
    cargarInvitaciones();
  }, []);

  // Resetear estado a BUSCANDO despues de mostrar resultado
  useEffect(() => {
    if (estado === ESTADO.ABIERTA || estado === ESTADO.ERROR) {
      const timer = setTimeout(() => setEstado(ESTADO.BUSCANDO), 5000);
      return () => clearTimeout(timer);
    }
  }, [estado]);

  async function cargarInvitaciones() {
    try {
      const data = await api.invitacionesActivas();
      setInvitaciones(data);
    } catch (e) {
      console.log('Error cargando invitaciones:', e.message);
    }
  }

  async function handleBeaconDetectado(uuid_ble) {
    if (estado === ESTADO.ABRIENDO) return;
    // Encontrar la invitacion que corresponde a este UUID
    const invitacion = invitaciones.find(inv =>
      inv.uuid_ble?.toLowerCase() === uuid_ble.toLowerCase()
    );
    await solicitarApertura(uuid_ble, invitacion?.id);
  }

  async function handleBotonManual(invitacion) {
    if (estado === ESTADO.ABRIENDO) return;
    await solicitarApertura(invitacion.uuid_ble, invitacion.id);
  }

  async function solicitarApertura(uuid_ble, invitacion_id) {
    setEstado(ESTADO.ABRIENDO);
    try {
      const data = await api.solicitarAcceso(uuid_ble, invitacion_id);
      setPuertaAbierta(data.puerta_nombre);
      setEstado(ESTADO.ABIERTA);
    } catch (e) {
      setMensajeError(e.message || 'No se pudo abrir la puerta.');
      setEstado(ESTADO.ERROR);
    }
  }

  // ---- Renders segun estado ----

  if (estado === ESTADO.ABRIENDO) {
    return (
      <View style={styles.centrado}>
        <ActivityIndicator size="large" color="#2E4A7A" />
        <Text style={styles.estadoTexto}>Abriendo puerta...</Text>
      </View>
    );
  }

  if (estado === ESTADO.ABIERTA) {
    return (
      <View style={styles.centrado}>
        <View style={styles.iconoExito}>
          <Text style={styles.iconoTexto}>✓</Text>
        </View>
        <Text style={styles.exitoTitulo}>Puerta abierta</Text>
        <Text style={styles.exitoSubtitulo}>{puertaAbierta}</Text>
      </View>
    );
  }

  if (estado === ESTADO.ERROR) {
    return (
      <View style={styles.centrado}>
        <View style={styles.iconoError}>
          <Text style={styles.iconoTexto}>✕</Text>
        </View>
        <Text style={styles.errorTitulo}>Acceso denegado</Text>
        <Text style={styles.errorSubtitulo}>{mensajeError}</Text>
      </View>
    );
  }

  // Estado BUSCANDO — pantalla principal
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.titulo}>Mis invitaciones</Text>
        <TouchableOpacity onPress={cerrarSesion}>
          <Text style={styles.cerrarSesion}>Salir</Text>
        </TouchableOpacity>
      </View>

      {/* Indicador BLE */}
      <View style={styles.bleIndicador}>
        <View style={[styles.bleDot, escaneando && styles.bleDotActivo]} />
        <Text style={styles.bleTexto}>
          {escaneando ? 'Detectando beacon... acercate a la puerta' : 'Bluetooth inactivo'}
        </Text>
      </View>

      {invitaciones.length === 0 ? (
        <View style={styles.centrado}>
          <Text style={styles.vacio}>No tienes invitaciones activas para hoy</Text>
        </View>
      ) : (
        <FlatList
          data={invitaciones}
          keyExtractor={item => item.id}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Text style={styles.cardEdificio}>{item.edificio_nombre || 'Edificio'}</Text>
              <Text style={styles.cardPuerta}>{item.puerta_nombre}</Text>
              <Text style={styles.cardFecha}>
                Hasta {new Date(item.fecha_hasta).toLocaleString('es-CL', { dateStyle: 'short', timeStyle: 'short' })}
              </Text>
              {/* Boton manual de respaldo si BLE no detecta automaticamente */}
              <TouchableOpacity
                style={styles.botonManual}
                onPress={() => handleBotonManual(item)}
              >
                <Text style={styles.botonManualTexto}>Solicitar entrada manualmente</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container:        { flex: 1, backgroundColor: '#F8F8F8' },
  centrado:         { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 32 },
  header:           { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
                      padding: 20, backgroundColor: '#2E4A7A' },
  titulo:           { fontSize: 20, fontWeight: '700', color: '#fff' },
  cerrarSesion:     { color: '#AAD4FF', fontSize: 14 },
  bleIndicador:     { flexDirection: 'row', alignItems: 'center', padding: 14,
                      backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#EEE', gap: 10 },
  bleDot:           { width: 10, height: 10, borderRadius: 5, backgroundColor: '#CCC' },
  bleDotActivo:     { backgroundColor: '#1D9E75' },
  bleTexto:         { fontSize: 13, color: '#555' },
  card:             { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginBottom: 12,
                      shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  cardEdificio:     { fontSize: 12, color: '#888', marginBottom: 2 },
  cardPuerta:       { fontSize: 18, fontWeight: '700', color: '#2E4A7A', marginBottom: 4 },
  cardFecha:        { fontSize: 13, color: '#888', marginBottom: 12 },
  botonManual:      { backgroundColor: '#2E4A7A', borderRadius: 10, padding: 14, alignItems: 'center' },
  botonManualTexto: { color: '#fff', fontSize: 14, fontWeight: '600' },
  iconoExito:       { width: 90, height: 90, borderRadius: 45, backgroundColor: '#1D9E75',
                      justifyContent: 'center', alignItems: 'center', marginBottom: 24 },
  iconoError:       { width: 90, height: 90, borderRadius: 45, backgroundColor: '#E24B4A',
                      justifyContent: 'center', alignItems: 'center', marginBottom: 24 },
  iconoTexto:       { fontSize: 40, color: '#fff', fontWeight: '700' },
  estadoTexto:      { fontSize: 18, color: '#555', marginTop: 20 },
  exitoTitulo:      { fontSize: 28, fontWeight: '700', color: '#1D6A4A', marginBottom: 8 },
  exitoSubtitulo:   { fontSize: 16, color: '#555' },
  errorTitulo:      { fontSize: 28, fontWeight: '700', color: '#A32D2D', marginBottom: 8 },
  errorSubtitulo:   { fontSize: 15, color: '#666', textAlign: 'center', lineHeight: 22 },
  vacio:            { fontSize: 15, color: '#AAA', textAlign: 'center', lineHeight: 22 },
});
