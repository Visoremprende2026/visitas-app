// ============================================================
//  app/(propietario)/nueva.js — Crear nueva invitacion
// ============================================================

import { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, Alert, ActivityIndicator, Platform
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { router } from 'expo-router';
import { api } from '../../services/api';

export default function NuevaVisita() {
  const [numero, setNumero] = useState('');
  const [puertaId, setPuertaId] = useState('');
  const [puertas, setPuertas] = useState([]);
  const [desde, setDesde] = useState(new Date());
  const [hasta, setHasta] = useState(new Date(Date.now() + 2 * 60 * 60 * 1000)); // +2 horas
  const [nota, setNota] = useState('');
  const [cargando, setCargando] = useState(false);
  const [mostrarDesde, setMostrarDesde] = useState(false);
  const [mostrarHasta, setMostrarHasta] = useState(false);

  useEffect(() => { cargarPuertas(); }, []);

  async function cargarPuertas() {
    try {
      const data = await api.listarPuertas();
      setPuertas(data);
      if (data.length > 0) setPuertaId(data[0].id);
    } catch (e) {
      Alert.alert('Error', 'No se pudieron cargar las puertas.');
    }
  }

  async function handleCrear() {
    const numeroLimpio = numero.trim();
    if (numeroLimpio.length < 9) {
      Alert.alert('Error', 'Ingresa el numero de celular del invitado.');
      return;
    }
    if (!puertaId) {
      Alert.alert('Error', 'Selecciona una puerta.');
      return;
    }
    if (hasta <= desde) {
      Alert.alert('Error', 'La fecha de termino debe ser posterior a la de inicio.');
      return;
    }

    const numeroFormateado = numeroLimpio.startsWith('+') ? numeroLimpio : `+56${numeroLimpio.replace(/^0/, '')}`;

    setCargando(true);
    try {
      await api.crearInvitacion({
        numero_invitado: numeroFormateado,
        puerta_id: puertaId,
        fecha_desde: desde.toISOString(),
        fecha_hasta: hasta.toISOString(),
        nota: nota.trim() || null,
      });
      Alert.alert('Invitacion creada', `Se notifico a ${numeroFormateado} por SMS.`, [
        { text: 'OK', onPress: () => router.replace('/(propietario)/visitas') }
      ]);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setCargando(false);
    }
  }

  const formatFecha = d => d.toLocaleString('es-CL', { dateStyle: 'short', timeStyle: 'short' });

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.label}>Numero de celular del invitado</Text>
      <TextInput
        style={styles.input}
        placeholder="+56 9 1234 5678"
        placeholderTextColor="#999"
        keyboardType="phone-pad"
        value={numero}
        onChangeText={setNumero}
      />

      <Text style={styles.label}>Puerta</Text>
      <View style={styles.puertas}>
        {puertas.map(p => (
          <TouchableOpacity
            key={p.id}
            style={[styles.puertaBtn, puertaId === p.id && styles.puertaBtnActivo]}
            onPress={() => setPuertaId(p.id)}
          >
            <Text style={[styles.puertaTexto, puertaId === p.id && styles.puertaTextoActivo]}>
              {p.nombre}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Desde</Text>
      <TouchableOpacity style={styles.fechaBtn} onPress={() => setMostrarDesde(true)}>
        <Text style={styles.fechaTexto}>{formatFecha(desde)}</Text>
      </TouchableOpacity>
      {mostrarDesde && (
        <DateTimePicker value={desde} mode="datetime" display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={(_, d) => { setMostrarDesde(false); if (d) setDesde(d); }} />
      )}

      <Text style={styles.label}>Hasta</Text>
      <TouchableOpacity style={styles.fechaBtn} onPress={() => setMostrarHasta(true)}>
        <Text style={styles.fechaTexto}>{formatFecha(hasta)}</Text>
      </TouchableOpacity>
      {mostrarHasta && (
        <DateTimePicker value={hasta} mode="datetime" display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={(_, d) => { setMostrarHasta(false); if (d) setHasta(d); }} />
      )}

      <Text style={styles.label}>Nota (opcional)</Text>
      <TextInput
        style={[styles.input, styles.inputNota]}
        placeholder="Ej: Visita para revision departamento"
        placeholderTextColor="#999"
        value={nota}
        onChangeText={setNota}
        multiline
        numberOfLines={3}
      />

      <TouchableOpacity
        style={[styles.boton, cargando && styles.botonDisabled]}
        onPress={handleCrear}
        disabled={cargando}
      >
        {cargando
          ? <ActivityIndicator color="#fff" />
          : <Text style={styles.botonTexto}>Crear invitacion</Text>
        }
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:          { flex: 1, backgroundColor: '#F8F8F8' },
  content:            { padding: 20 },
  label:              { fontSize: 14, fontWeight: '600', color: '#444', marginBottom: 8, marginTop: 16 },
  input:              { backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#DDD', borderRadius: 12,
                        padding: 14, fontSize: 16, color: '#222' },
  inputNota:          { height: 90, textAlignVertical: 'top' },
  puertas:            { flexDirection: 'row', gap: 10 },
  puertaBtn:          { flex: 1, padding: 14, borderRadius: 12, borderWidth: 1.5, borderColor: '#DDD',
                        backgroundColor: '#fff', alignItems: 'center' },
  puertaBtnActivo:    { backgroundColor: '#2E4A7A', borderColor: '#2E4A7A' },
  puertaTexto:        { fontSize: 14, color: '#555', fontWeight: '600' },
  puertaTextoActivo:  { color: '#fff' },
  fechaBtn:           { backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#DDD', borderRadius: 12,
                        padding: 14 },
  fechaTexto:         { fontSize: 16, color: '#222' },
  boton:              { backgroundColor: '#2E4A7A', borderRadius: 12, padding: 18, alignItems: 'center', marginTop: 32, marginBottom: 40 },
  botonDisabled:      { opacity: 0.6 },
  botonTexto:         { color: '#fff', fontSize: 16, fontWeight: '600' },
});
