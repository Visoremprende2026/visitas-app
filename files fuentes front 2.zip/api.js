// ============================================================
//  services/api.js — Cliente HTTP hacia el backend FastAPI
//  Todas las llamadas al backend pasan por aqui
// ============================================================

import * as SecureStore from 'expo-secure-store';

const BASE_URL = 'http://192.168.1.100:8000'; // Cambiar por IP real del servidor

// ---- helpers ----

async function getToken() {
  return await SecureStore.getItemAsync('jwt_token');
}

async function request(path, options = {}) {
  const token = await getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const response = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.detail || 'Error en el servidor');
  }

  return data;
}

// ---- Auth ----

export const api = {

  // Solicita OTP SMS
  solicitarOTP: (numero_celular) =>
    request('/auth/otp/request', {
      method: 'POST',
      body: JSON.stringify({ numero_celular }),
    }),

  // Verifica OTP y retorna JWT + perfil
  verificarOTP: (numero_celular, codigo) =>
    request('/auth/otp/verify', {
      method: 'POST',
      body: JSON.stringify({ numero_celular, codigo }),
    }),

  // Renueva el JWT
  refreshToken: () =>
    request('/auth/refresh', { method: 'POST' }),

  // ---- Invitaciones ----

  crearInvitacion: (datos) =>
    request('/invitaciones', {
      method: 'POST',
      body: JSON.stringify(datos),
    }),

  listarInvitaciones: (estado = 'todas') =>
    request(`/invitaciones?estado=${estado}`),

  invitacionesActivas: () =>
    request('/invitaciones/activas'),

  actualizarInvitacion: (id, datos) =>
    request(`/invitaciones/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(datos),
    }),

  cancelarInvitacion: (id) =>
    request(`/invitaciones/${id}`, { method: 'DELETE' }),

  // ---- Acceso ----

  solicitarAcceso: (uuid_ble, invitacion_id = null) =>
    request('/acceso/solicitar', {
      method: 'POST',
      body: JSON.stringify({ uuid_ble, invitacion_id }),
    }),

  logAccesos: (limite = 50) =>
    request(`/acceso/log?limite=${limite}`),

  listarPuertas: () =>
    request('/acceso/puertas'),

  // ---- Dispositivos ----

  registrarPushToken: (token, plataforma) =>
    request('/dispositivos/push-token', {
      method: 'POST',
      body: JSON.stringify({ token, plataforma }),
    }),
};
