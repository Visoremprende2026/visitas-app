// ============================================================
//  app/(auth)/verify.js — Verificacion del codigo OTP
// ============================================================

import { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, Alert, ActivityIndicator
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { api } from '../../services/api';
import { useAuth } from '../../hooks/useAuth';

export default function Verify() {
  const { numero } = useLocalSearchParams();
  const { guardarSesion } = useAuth();
  const [codigo, setCodigo] = useState('');
  const [cargando, setCargando] = useState(false);
  const inputRef = useRef(null);

  async function handleVerificar() {
    if (codigo.length !== 6) {
      Alert.alert('Error', 'El codigo tiene 6 digitos.');
      return;
    }

    setCargando(true);
    try {
      const data = await api.verificarOTP(numero, codigo);
      // Guardar JWT y perfil en almacenamiento seguro
      await guardarSesion(data.access_token, data.perfil, numero, data.edificio_id);
      // index.js detecta el cambio y redirige segun perfil
      router.replace('/');
    } catch (e) {
      Alert.alert('Codigo incorrecto', e.message || 'Verifica el codigo e intenta de nuevo.');
      setCodigo('');
      inputRef.current?.focus();
    } finally {
      setCargando(false);
    }
  }

  async function handleReenviar() {
    try {
      await api.solicitarOTP(numero);
      Alert.alert('Codigo enviado', 'Te enviamos un nuevo codigo SMS.');
    } catch (e) {
      Alert.alert('Error', 'No se pudo reenviar. Intenta en unos segundos.');
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.titulo}>Codigo SMS</Text>
        <Text style={styles.subtitulo}>
          Ingresa el codigo de 6 digitos enviado a{'\n'}
          <Text style={styles.numero}>{numero}</Text>
        </Text>

        <TextInput
          ref={inputRef}
          style={styles.inputCodigo}
          placeholder="------"
          placeholderTextColor="#CCC"
          keyboardType="number-pad"
          value={codigo}
          onChangeText={v => { if (v.length <= 6) setCodigo(v); }}
          maxLength={6}
          autoFocus
          textAlign="center"
          letterSpacing={12}
        />

        <TouchableOpacity
          style={[styles.boton, (cargando || codigo.length < 6) && styles.botonDisabled]}
          onPress={handleVerificar}
          disabled={cargando || codigo.length < 6}
        >
          {cargando
            ? <ActivityIndicator color="#fff" />
            : <Text style={styles.botonTexto}>Verificar</Text>
          }
        </TouchableOpacity>

        <TouchableOpacity style={styles.linkReenviar} onPress={handleReenviar}>
          <Text style={styles.linkTexto}>No recibi el codigo — reenviar</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.linkVolver} onPress={() => router.back()}>
          <Text style={styles.linkTexto}>Cambiar numero</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container:     { flex: 1, backgroundColor: '#fff' },
  content:       { flex: 1, justifyContent: 'center', paddingHorizontal: 32 },
  titulo:        { fontSize: 28, fontWeight: '700', color: '#2E4A7A', marginBottom: 8 },
  subtitulo:     { fontSize: 16, color: '#666', marginBottom: 40, lineHeight: 24 },
  numero:        { fontWeight: '700', color: '#2E4A7A' },
  inputCodigo:   { borderWidth: 1.5, borderColor: '#DDD', borderRadius: 12, padding: 20,
                   fontSize: 32, fontWeight: '700', color: '#222', marginBottom: 24 },
  boton:         { backgroundColor: '#2E4A7A', borderRadius: 12, padding: 18, alignItems: 'center', marginBottom: 16 },
  botonDisabled: { opacity: 0.4 },
  botonTexto:    { color: '#fff', fontSize: 16, fontWeight: '600' },
  linkReenviar:  { alignItems: 'center', paddingVertical: 10 },
  linkVolver:    { alignItems: 'center', paddingVertical: 10 },
  linkTexto:     { color: '#2E4A7A', fontSize: 15 },
});
