// ============================================================
//  app/(auth)/login.js — Pantalla de login con OTP
// ============================================================

import { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, Alert, KeyboardAvoidingView, Platform, ActivityIndicator
} from 'react-native';
import { router } from 'expo-router';
import { api } from '../../services/api';

export default function Login() {
  const [numero, setNumero] = useState('');
  const [cargando, setCargando] = useState(false);

  async function handleSolicitarOTP() {
    const numeroLimpio = numero.trim();
    if (numeroLimpio.length < 9) {
      Alert.alert('Error', 'Ingresa un numero de celular valido.');
      return;
    }

    // Formatear numero chileno si no tiene prefijo
    const numeroFormateado = numeroLimpio.startsWith('+')
      ? numeroLimpio
      : `+56${numeroLimpio.replace(/^0/, '')}`;

    setCargando(true);
    try {
      await api.solicitarOTP(numeroFormateado);
      router.push({ pathname: '/(auth)/verify', params: { numero: numeroFormateado } });
    } catch (e) {
      Alert.alert('Error', e.message || 'No se pudo enviar el codigo.');
    } finally {
      setCargando(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.content}>
        <Text style={styles.titulo}>Bienvenido</Text>
        <Text style={styles.subtitulo}>Ingresa tu numero de celular para continuar</Text>

        <TextInput
          style={styles.input}
          placeholder="+56 9 1234 5678"
          placeholderTextColor="#999"
          keyboardType="phone-pad"
          value={numero}
          onChangeText={setNumero}
          autoFocus
          maxLength={15}
        />

        <TouchableOpacity
          style={[styles.boton, cargando && styles.botonDisabled]}
          onPress={handleSolicitarOTP}
          disabled={cargando}
        >
          {cargando
            ? <ActivityIndicator color="#fff" />
            : <Text style={styles.botonTexto}>Enviar codigo SMS</Text>
          }
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1, backgroundColor: '#fff' },
  content:      { flex: 1, justifyContent: 'center', paddingHorizontal: 32 },
  titulo:       { fontSize: 28, fontWeight: '700', color: '#2E4A7A', marginBottom: 8 },
  subtitulo:    { fontSize: 16, color: '#666', marginBottom: 40, lineHeight: 22 },
  input:        { borderWidth: 1.5, borderColor: '#DDD', borderRadius: 12, padding: 16,
                  fontSize: 18, color: '#222', marginBottom: 20 },
  boton:        { backgroundColor: '#2E4A7A', borderRadius: 12, padding: 18, alignItems: 'center' },
  botonDisabled:{ opacity: 0.6 },
  botonTexto:   { color: '#fff', fontSize: 16, fontWeight: '600' },
});
