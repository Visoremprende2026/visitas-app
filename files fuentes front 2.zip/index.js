// ============================================================
//  app/index.js — Pantalla inicial
//  Redirige a login o a la pantalla correcta segun perfil
// ============================================================

import { useEffect } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../hooks/useAuth';
import * as Notifications from 'expo-notifications';
import { api } from '../services/api';
import { Platform } from 'react-native';

export default function Index() {
  const { usuario, cargando } = useAuth();

  useEffect(() => {
    if (cargando) return;

    if (!usuario) {
      router.replace('/(auth)/login');
      return;
    }

    // Registrar token push al iniciar sesion
    registrarPushToken();

    // Redirigir segun perfil
    if (usuario.perfil === 'propietario') {
      router.replace('/(propietario)/visitas');
    } else {
      router.replace('/(invitado)/entrada');
    }
  }, [cargando, usuario]);

  async function registrarPushToken() {
    try {
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== 'granted') return;

      const tokenData = await Notifications.getExpoPushTokenAsync();
      const plataforma = Platform.OS; // 'ios' o 'android'
      await api.registrarPushToken(tokenData.data, plataforma);
    } catch (e) {
      console.log('Error registrando push token:', e.message);
    }
  }

  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color="#2E4A7A" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
});
