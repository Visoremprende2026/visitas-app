// ============================================================
//  hooks/useAuth.js — Manejo de sesion y JWT
// ============================================================

import { useState, useEffect, createContext, useContext } from 'react';
import * as SecureStore from 'expo-secure-store';
import { router } from 'expo-router';
import { api } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(null);  // { numero, perfil, edificio_id }
  const [cargando, setCargando] = useState(true);

  // Al arrancar la app, verificar si hay JWT guardado
  useEffect(() => {
    verificarSesionGuardada();
  }, []);

  async function verificarSesionGuardada() {
    try {
      const token = await SecureStore.getItemAsync('jwt_token');
      const perfil = await SecureStore.getItemAsync('perfil');
      const numero = await SecureStore.getItemAsync('numero_celular');
      const edificio_id = await SecureStore.getItemAsync('edificio_id');

      if (token && perfil && numero) {
        setUsuario({ numero, perfil, edificio_id });
      }
    } catch (e) {
      console.log('Sin sesion guardada');
    } finally {
      setCargando(false);
    }
  }

  async function guardarSesion(token, perfil, numero, edificio_id) {
    await SecureStore.setItemAsync('jwt_token', token);
    await SecureStore.setItemAsync('perfil', perfil);
    await SecureStore.setItemAsync('numero_celular', numero);
    await SecureStore.setItemAsync('edificio_id', edificio_id || '');
    setUsuario({ numero, perfil, edificio_id });
  }

  async function cerrarSesion() {
    await SecureStore.deleteItemAsync('jwt_token');
    await SecureStore.deleteItemAsync('perfil');
    await SecureStore.deleteItemAsync('numero_celular');
    await SecureStore.deleteItemAsync('edificio_id');
    setUsuario(null);
    router.replace('/(auth)/login');
  }

  return (
    <AuthContext.Provider value={{ usuario, cargando, guardarSesion, cerrarSesion }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
